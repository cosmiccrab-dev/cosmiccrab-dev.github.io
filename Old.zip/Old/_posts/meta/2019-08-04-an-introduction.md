---
layout: wrapper
title:  "A Brief Introduction"
date: 2019-08-04 15:07:15 -0500
categories: meta
permalink: "/blog/:categories/:title"
---

Welcome to Saucy Armadillo Games. Aside from our Twitter and Discord, we felt it's a good idea to document our efforts in a more professional way.
For those that stumbled here through some SEO wizardry, greetings! We are a small indie game company comprised of three game developers.

Avis [@agentavis](https://twitter.com/agentavis) 📄🎨

Josh [@staticlofi](https://twitter.com/staticlofi) 📄

Garry [@bytecauldron](https://twitter.com/bytecauldron) 📄🎨🎵

We will be documenting our game-making efforts here. If you want to stay up-to-date, subscribe to our rss feed. If you don't know what that is (kids these days), you can also join our Discord server.

We look forward to revealing some of the cool stuff we're making. Stay tuned!
